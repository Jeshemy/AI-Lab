"""Train and evaluate SAFE Flow's tabular intrusion classifier."""

from __future__ import annotations

import json
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier


ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "cybersecurity_intrusion_data.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "safe_flow_model.joblib"
EVALUATION_PATH = MODEL_DIR / "evaluation.json"
SOURCE_URL = "https://www.kaggle.com/datasets/dnkumars/cybersecurity-intrusion-detection-dataset"
TARGET = "attack_detected"
ID_COLUMN = "session_id"
NUMERIC_FEATURES = [
    "network_packet_size", "login_attempts", "session_duration",
    "ip_reputation_score", "failed_logins", "unusual_time_access",
]
CATEGORICAL_FEATURES = ["protocol_type", "encryption_used", "browser_type"]
FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES
RANDOM_STATE = 42
TEST_SIZE = 0.20


def metric_summary(y_true, y_pred):
    return {
        "accuracy": round(float(accuracy_score(y_true, y_pred)), 6),
        "precision": round(float(precision_score(y_true, y_pred, pos_label=1, zero_division=0)), 6),
        "recall": round(float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)), 6),
        "f1": round(float(f1_score(y_true, y_pred, pos_label=1, zero_division=0)), 6),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist(),
    }


def make_pipeline(classifier):
    numeric = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("one_hot", OneHotEncoder(handle_unknown="ignore")),
    ])
    preprocess = ColumnTransformer([
        ("numeric", numeric, NUMERIC_FEATURES),
        ("categorical", categorical, CATEGORICAL_FEATURES),
    ])
    return Pipeline([("preprocess", preprocess), ("classifier", classifier)])


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")

    # Preserve the literal category "None" in encryption_used; pandas otherwise
    # interprets it as a missing token and silently removes a real category.
    frame = pd.read_csv(DATA_PATH, keep_default_na=False)
    for column in FEATURES + [TARGET]:
        frame[column] = frame[column].replace(r"^\s*$", pd.NA, regex=True)
    required = set(FEATURES + [TARGET, ID_COLUMN])
    missing_columns = sorted(required - set(frame.columns))
    if missing_columns:
        raise ValueError(f"Dataset is missing required columns: {', '.join(missing_columns)}")
    if frame.empty:
        raise ValueError("Dataset contains no records.")

    # Remove identifiers from the predictors to prevent row-ID leakage.
    X = frame[FEATURES].copy()
    y = pd.to_numeric(frame[TARGET], errors="raise").astype(int)
    if set(y.unique()) != {0, 1}:
        raise ValueError("attack_detected must contain both binary labels 0 and 1.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, stratify=y, random_state=RANDOM_STATE
    )

    candidates = {
        "Logistic Regression": LogisticRegression(
            max_iter=2500, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(
            class_weight="balanced", min_samples_leaf=3, random_state=RANDOM_STATE
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, class_weight="balanced_subsample", n_jobs=-1,
            random_state=RANDOM_STATE,
        ),
        "SVM": SVC(
            C=1.0, kernel="rbf", class_weight="balanced", probability=True,
            random_state=RANDOM_STATE,
        ),
    }
    scoring = {"attack_recall": "recall", "attack_f1": "f1", "accuracy": "accuracy"}
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=RANDOM_STATE)
    fitted_candidates = {}
    comparison = []

    for name, classifier in candidates.items():
        pipeline = make_pipeline(classifier)
        cv_scores = cross_validate(
            pipeline, X_train, y_train, cv=cv, scoring=scoring, n_jobs=1,
            error_score="raise",
        )
        pipeline.fit(X_train, y_train)
        test_metrics = metric_summary(y_test, pipeline.predict(X_test))
        record = {
            "name": name,
            "cv_attack_recall": round(float(cv_scores["test_attack_recall"].mean()), 6),
            "cv_attack_f1": round(float(cv_scores["test_attack_f1"].mean()), 6),
            "cv_accuracy": round(float(cv_scores["test_accuracy"].mean()), 6),
            **test_metrics,
        }
        comparison.append(record)
        fitted_candidates[name] = pipeline
        print(
            f"{name}: CV attack recall={record['cv_attack_recall']:.4f}, "
            f"CV F1={record['cv_attack_f1']:.4f}, test recall={record['recall']:.4f}, "
            f"test F1={record['f1']:.4f}"
        )

    # Select on training-only cross-validation; keep the stratified holdout for reporting.
    comparison.sort(
        key=lambda item: (item["cv_attack_recall"], item["cv_attack_f1"], item["cv_accuracy"]),
        reverse=True,
    )
    selected_name = comparison[0]["name"]
    selected = fitted_candidates[selected_name]
    selected_metrics = next(item for item in comparison if item["name"] == selected_name)

    # Baselines support local, one-feature-at-a-time sensitivity explanations in the app.
    baseline = {}
    for feature in NUMERIC_FEATURES:
        baseline[feature] = float(pd.to_numeric(X_train[feature], errors="coerce").median())
    for feature in CATEGORICAL_FEATURES:
        modes = X_train[feature].dropna().mode()
        baseline[feature] = str(modes.iloc[0]) if not modes.empty else "Unknown"

    class_counts = {"normal": int((y == 0).sum()), "attack": int((y == 1).sum())}
    all_missing_cells = int(frame[FEATURES + [TARGET]].isna().sum().sum())
    evaluation = {
        "dataset": {
            "name": "Cybersecurity Intrusion Detection Dataset",
            "source_url": SOURCE_URL,
            "license": "MIT",
            "records": int(len(frame)),
            "predictor_features": int(len(FEATURES)),
            "features": FEATURES,
            "target": TARGET,
            "class_counts": class_counts,
            "missing_values": all_missing_cells,
            "duplicate_rows": int(frame.duplicated().sum()),
            "dataset_tagged_synthetic": True,
        },
        "preprocessing": [
            "Excluded session_id from model predictors to avoid identifier leakage.",
            "Imputed numeric values with the training median and standardized them.",
            "Imputed categorical values with the training mode and one-hot encoded them.",
            "Used stratified sampling to preserve normal/attack proportions.",
        ],
        "split": {
            "method": "Stratified 80/20 train/test holdout",
            "train_records": int(len(X_train)),
            "test_records": int(len(X_test)),
            "random_state": RANDOM_STATE,
            "selection_cv": "3-fold stratified cross-validation on training data",
            "selection_rule": "Highest mean attack recall; ties broken by attack F1, then accuracy.",
        },
        "selected_model": selected_name,
        "selected_cv": {
            "attack_recall": selected_metrics["cv_attack_recall"],
            "attack_f1": selected_metrics["cv_attack_f1"],
            "accuracy": selected_metrics["cv_accuracy"],
        },
        "test_metrics": {
            key: selected_metrics[key]
            for key in ("accuracy", "precision", "recall", "f1", "confusion_matrix")
        },
        "comparison": comparison,
        "positive_class": "Attack (attack_detected = 1)",
        "confusion_matrix_labels": ["Normal", "Attack"],
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": selected, "features": FEATURES, "baseline": baseline}, MODEL_PATH)
    EVALUATION_PATH.write_text(json.dumps(evaluation, indent=2), encoding="utf-8")
    print(f"Selected model: {selected_name}")
    print(f"Test metrics: {json.dumps(evaluation['test_metrics'])}")
    print(f"Saved model: {MODEL_PATH}")
    print(f"Saved evaluation: {EVALUATION_PATH}")


if __name__ == "__main__":
    main()
