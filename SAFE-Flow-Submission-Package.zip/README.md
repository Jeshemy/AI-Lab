# SAFE Flow

SAFE Flow (Stratified Analysis for Network Flow) is a Computer Engineering web project for screening network sessions as normal or attack. It uses a fitted scikit-learn pipeline trained on a public labeled dataset and exposes manual-entry and CSV analysis through Flask. Results support review and do not monitor live traffic or block attacks.

## Dataset and attribution

The included `data/cybersecurity_intrusion_data.csv` is Dinesh Naveen Kumar Samudrala’s *Cybersecurity Intrusion Detection Dataset* on [Kaggle](https://www.kaggle.com/datasets/dnkumars/cybersecurity-intrusion-detection-dataset). Kaggle lists the dataset license as MIT. It contains 9,537 records, nine predictor fields, and the binary target `attack_detected` (0 = normal, 1 = attack). Its Kaggle metadata tags the dataset as synthetic, so reported performance should not be generalized to real network traffic.

The predictor fields are `network_packet_size`, `protocol_type`, `login_attempts`, `session_duration`, `encryption_used`, `ip_reputation_score`, `failed_logins`, `browser_type`, and `unusual_time_access`. The identifier `session_id` is excluded from training. The literal `None` value in `encryption_used` is preserved as a valid category. The dataset contains no missing predictor/target values and no duplicate rows.

## Training and evaluation

Install the dependencies, then run:

```powershell
python training/train_model.py
```

The script uses a stratified 80/20 train/test split with a fixed random seed. It fits preprocessing and four classifiers on training data, compares them with stratified 3-fold cross-validation, and selects by mean attack recall, using attack F1 and accuracy as tie-breakers. Numeric values are median-imputed and standardized; categories are mode-imputed and one-hot encoded. The selected model is evaluated on the held-out test split with accuracy, precision, recall, F1, and a confusion matrix. The pipeline is saved to `models/safe_flow_model.joblib`, with dataset details and metrics in `models/evaluation.json`.

The current training run selected **Decision Tree**. On the 1,908-row held-out split it achieved 82.08% accuracy, 80.67% precision, 78.78% attack recall, and 79.72% F1. Confusion matrix (actual rows, predicted columns): `[[894, 161], [181, 672]]`. The About page shows the measured comparison for all four classifiers. These results describe this synthetic dataset and split; they are not production validation.

## Run locally

Requires Python 3.10 or newer. On Windows, double-click `Start-SAFE-Flow.bat`. It creates `.venv`, installs `requirements.txt` on first use, opens the browser, and starts the app. Keep the command window open while using SAFE Flow.

To start manually:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

## Web application features

- Home overview with the problem, intended users, and program fit.
- Manual session form with nine dataset fields and a trained-model prediction with probability and input-sensitivity summary.
- CSV preview, automatic/manual feature mapping, batch predictions, 25-row pagination, and full results export.
- About page with dataset source, class distribution, preprocessing and training methodology, four-model comparison, holdout metrics, and confusion matrix.
- Program relevance page with the problem statement, AI role, Computer Engineering alignment, and target users.

CSV uploads accept comma, semicolon, tab, or pipe delimiters and UTF-8, UTF-16, and common Windows encodings. Uploads are limited to 64 MB and 50,000 data rows. Unmapped rows are exported without a fabricated prediction. The trained pipeline imputes missing mapped values using statistics learned from the training split and ignores unknown categorical values safely.

## Project scope

The dataset contains session-level records. SAFE Flow does not capture packets, monitor live traffic, identify attack subtypes, or replace a security system. IP reputation values follow the Kaggle description: higher values indicate more suspicious activity.
