from __future__ import annotations

import csv
import io
import json
import math
import os

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024

FIELDS = {
    "login_attempts": ("Login attempts", 0, 10000),
    "failed_logins": ("Failed logins", 0, 10000),
    "session_duration": ("Session duration (seconds)", 0, 86400),
    "network_packet_size": ("Network packet size (bytes)", 0, 10000000),
    "ip_reputation_score": ("IP reputation score", 0, 1),
    "protocol_type": ("Protocol", None, None),
    "encryption_used": ("Encryption", None, None),
    "browser_type": ("Browser", None, None),
    "unusual_time_access": ("Unusual time access", None, None),
}
ALIASES = {
    "login_attempts": ["login attempts", "login_attempts", "attempts", "auth attempts", "authentication attempts"],
    "failed_logins": ["failed logins", "failed_logins", "failed login attempts", "failed attempts", "login failures"],
    "session_duration": ["session duration", "session_duration", "duration", "flow duration"],
    "network_packet_size": ["network packet size", "network_packet_size", "packet size", "packet_length", "packet length"],
    "ip_reputation_score": ["ip reputation score", "ip_reputation_score", "reputation", "ip reputation", "reputation score"],
    "protocol_type": ["protocol", "protocol_type", "protocol type"],
    "encryption_used": ["encryption", "encryption_used", "encryption used"],
    "browser_type": ["browser", "browser_type", "browser type"],
    "unusual_time_access": ["unusual time access", "unusual_time_access", "unusual access", "access time unusual"],
}


def parse_csv_upload(file):
    raw = file.stream.read()
    text = None
    for encoding in ("utf-8-sig", "utf-16", "cp1252", "latin-1"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    if text is None:
        raise ValueError("This file encoding is not supported. Save it as CSV and try again.")
    sample = text[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(io.StringIO(text), dialect)
    try:
        headers = next(reader)
    except StopIteration:
        raise ValueError("This CSV is empty.")
    headers = [str(h).strip() or f"Column {i + 1}" for i, h in enumerate(headers)]
    if not headers:
        raise ValueError("The CSV needs a header row.")
    # DictReader otherwise silently overwrites duplicate/blank header names.
    seen, unique_headers = {}, []
    for header in headers:
        seen[header] = seen.get(header, 0) + 1
        unique_headers.append(header if seen[header] == 1 else f"{header} ({seen[header]})")
    rows = []
    for values in reader:
        if not values or all(not value.strip() for value in values):
            continue
        row = {header: (values[i].strip() if i < len(values) else "") for i, header in enumerate(unique_headers)}
        if len(values) > len(unique_headers):
            row["Extra values"] = ", ".join(values[len(unique_headers):])
        rows.append(row)
        if len(rows) > 50000:
            raise ValueError("This upload has more than 50,000 data rows. Split it into smaller CSV files and retry.")
    if not rows:
        raise ValueError("The CSV has a header but no data rows.")
    return unique_headers, rows


def detect_mapping(headers):
    lookup = {header.strip().lower(): header for header in headers}
    mapping = {}
    for field, aliases in ALIASES.items():
        for alias in aliases:
            if alias.lower() in lookup:
                mapping[field] = lookup[alias.lower()]
                break
    return mapping


def predict(row: dict) -> dict:
    """Transparent demonstration score; replace with the saved project model."""
    def number(key: str, default: float = 0) -> float:
        try:
            value = float(row.get(key, default))
            return value if math.isfinite(value) else default
        except (TypeError, ValueError):
            return default

    failed = max(0, number("failed_logins"))
    attempts = max(0, number("login_attempts"))
    reputation = min(1, max(0, number("ip_reputation_score", 0.5)))
    packet = max(0, number("network_packet_size"))
    unusual = str(row.get("unusual_time_access", "no")).strip().lower() in {"yes", "true", "1", "unusual"}

    # A heuristic for demonstration only, not a fitted or validated ML model.
    components = [
        ("Failed logins", min(failed, 12) * 0.045),
        ("IP reputation", (1 - reputation) * 0.38),
        ("Unusual access time", 0.16 if unusual else 0),
        ("Login attempts", min(attempts, 20) * 0.008),
        ("Large packet size", 0.08 if packet > 1400 else 0),
    ]
    score = 0.08 + sum(value for _, value in components)
    score = min(0.98, max(0.02, score))
    label = "Attack" if score >= 0.5 else "Normal"
    reasons = []
    if failed >= 3: reasons.append(f"{int(failed)} failed logins")
    if reputation <= 0.35: reasons.append("low IP reputation")
    if unusual: reasons.append("unusual access time")
    if attempts >= 8: reasons.append("frequent login attempts")
    if not reasons: reasons.append("no strong demo risk signals")
    strongest = max((value for _, value in components), default=0)
    factors = [{"label": name, "strength": round(value / strongest * 100)}
               for name, value in sorted(components, key=lambda item: item[1], reverse=True)
               if value > 0][:4] if strongest else []
    return {"prediction": label, "probability": round(score if label == "Attack" else 1-score, 4),
            "attack_probability": round(score, 4), "explanation": ", ".join(reasons),
            "factors": factors}


@app.get("/")
def home(): return render_template("index.html", page="home")

@app.get("/predict")
def predict_page(): return render_template("index.html", page="predict")

@app.get("/about")
def about(): return render_template("index.html", page="about")

@app.get("/relevance")
def relevance(): return render_template("index.html", page="relevance")

@app.post("/api/predict")
def predict_api():
    data = request.get_json(silent=True) or {}
    for key, (label, low, high) in FIELDS.items():
        if key in data and low is not None:
            try: value = float(data[key])
            except (TypeError, ValueError): return jsonify(error=f"{label} must be a number."), 400
            if not math.isfinite(value) or value < low or value > high:
                return jsonify(error=f"{label} must be between {low} and {high}."), 400
    return jsonify(predict(data))


@app.post("/api/inspect-csv")
def inspect_csv_api():
    file = request.files.get("file")
    if not file:
        return jsonify(error="Choose a CSV file to inspect."), 400
    try:
        headers, rows = parse_csv_upload(file)
        return jsonify(filename=file.filename or "uploaded.csv", headers=headers, total=len(rows),
                       preview=rows[:5], auto_mapping=detect_mapping(headers))
    except (ValueError, csv.Error) as exc:
        return jsonify(error=str(exc) or "Could not read this CSV."), 400

@app.post("/api/upload")
def upload_api():
    file = request.files.get("file")
    if not file:
        return jsonify(error="Choose a CSV file to analyze."), 400
    try:
        headers, rows = parse_csv_upload(file)
        try:
            requested_mapping = json.loads(request.form.get("mapping", "{}"))
        except json.JSONDecodeError:
            requested_mapping = {}
        available = set(headers)
        mapping = {field: source for field, source in requested_mapping.items()
                   if field in FIELDS and source in available}
        if not mapping:
            mapping = detect_mapping(headers)
        results = []
        for index, row in enumerate(rows, 1):
            if not mapping:
                results.append({"row": index, "source": row, "prediction": "Needs mapping", "probability": None,
                                "attack_probability": None, "explanation": "No columns were mapped to session features."})
                continue
            features = {field: row.get(source, "") for field, source in mapping.items()}
            result = predict(features)
            results.append({"row": index, "source": row, **result})
        return jsonify(results=results, total=len(results), attacks=sum(r["prediction"] == "Attack" for r in results),
                       normals=sum(r["prediction"] == "Normal" for r in results),
                       unmapped=sum(r["prediction"] == "Needs mapping" for r in results),
                       headers=headers, mapping=mapping, mapped_count=len(mapping), filename=file.filename or "uploaded.csv")
    except (ValueError, csv.Error) as exc:
        return jsonify(error=str(exc) or "Could not read this CSV."), 400


@app.errorhandler(413)
def too_large(_error):
    return jsonify(error="This file is larger than 64 MB. Save a smaller CSV or split it into files."), 413

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), debug=False)
