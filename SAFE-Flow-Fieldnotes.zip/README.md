# SAFE Flow — Fieldnotes Theme

SAFE Flow (Stratified Analysis for Network Flow) is a Flask web application based on the Group 4 proposal and Progress Report 1. It includes Home, Predict, About, and Relevance pages, manual session entry, CSV batch analysis, probability scores, and short explanations.

The analysis screen shows the session result, probability score, short explanation, and relative demo-heuristic signals. CSV uploads produce a paginated results table (25 rows per page) and a downloadable export of all rows. The About page includes dataset details, the planned four-model comparison, a class distribution chart state, evaluation metrics, and a confusion matrix. Dataset counts and evaluation values remain marked as pending until the dataset and trained model are supplied.

## Run locally

Requires Python 3.10 or newer.

On Windows, double-click `Start-SAFE-Flow.bat`. It creates the virtual environment, installs Flask on first use, opens the browser, and starts the app. Leave the command window open while using SAFE Flow. Close that window to stop the server.

If you prefer Command Prompt:

```powershell
cd SAFE-Flow-Fieldnotes
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000.

## CSV uploads

CSV uploads can use different column names and comma, semicolon, tab, or pipe delimiters. UTF-8, UTF-16, and common Windows encodings are supported. The upload screen previews the file, automatically matches familiar session-feature names, and lets the user map unfamiliar column names. Unmapped files can still be opened and exported; rows without any mapped session feature are labeled “Needs mapping” and do not receive a fabricated score. Uploads are limited to 64 MB and 50,000 data rows per file. The results export preserves every original column and adds the screening fields.

## Model status and publishing

The supplied PDFs describe the intended dataset and model comparisons but do not include the dataset or a trained model artifact. The included predictor is therefore a deterministic, transparent demonstration heuristic. It is clearly marked throughout the site and must not be presented as measured machine-learning performance. For a research-valid release, train and evaluate the proposed Logistic Regression, Decision Tree, SVM, and Random Forest models on the specified Kaggle dataset, save the selected model and preprocessing pipeline, and connect that pipeline in `app.py` before publishing model-performance claims. Deploy the Flask app using a WSGI server and HTTPS on a Python host; set `HOST=0.0.0.0` when the hosting platform requires an externally bound process.

The project is limited to session-level classification. It does not capture packets, monitor live traffic, block attacks, or identify a specific attack type.
