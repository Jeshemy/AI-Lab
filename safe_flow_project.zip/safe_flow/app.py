"""
SAFE Flow - Flask web application (paper section II.F)
Pages: Home, Predict, About, Relevance
The saved model, scaler and encoder are loaded ONCE at start-up.

Run:  python app.py   ->  http://127.0.0.1:5000
"""
import io
import json
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request

BASE = Path(__file__).parent
MODEL_PATH = BASE / "models" / "safe_flow_model.joblib"
REPORT_PATH = BASE / "models" / "report.json"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB upload limit

if not MODEL_PATH.exists():
    raise SystemExit("Model not found. Run `python train_model.py` first.")

bundle = joblib.load(MODEL_PATH)
PRE, MODEL = bundle["preprocessor"], bundle["model"]
FEATURES, NUM, CAT = bundle["features"], bundle["numerical"], bundle["categorical"]
BASELINES, CATEGORIES = bundle["baselines"], bundle["categories"]
REPORT = json.loads(REPORT_PATH.read_text()) if REPORT_PATH.exists() else {}

LABELS = {
    "network_packet_size": "Packet size", "login_attempts": "Login attempts",
    "session_duration": "Session duration", "ip_reputation_score": "IP reputation score",
    "failed_logins": "Failed logins", "unusual_time_access": "Unusual time access",
    "protocol_type": "Protocol type", "encryption_used": "Encryption used",
    "browser_type": "Browser type",
}
# Valid ranges used for input validation (server side)
RANGES = {
    "network_packet_size": (0, 100000), "login_attempts": (0, 1000),
    "session_duration": (0, 1e7), "ip_reputation_score": (0, 1),
    "failed_logins": (0, 1000), "unusual_time_access": (0, 1),
}


# ------------------------------------------------------------------ helpers
def validate_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Check columns/values and return a clean frame in training column order."""
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        raise ValueError("Missing column(s): " + ", ".join(missing))
    df = df[FEATURES].copy()
    for c in NUM:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if df[NUM].isna().any().any():
        raise ValueError("Numeric columns contain empty or non-numeric values.")
    for c, (lo, hi) in RANGES.items():
        if not df[c].between(lo, hi).all():
            raise ValueError(f"{LABELS[c]} must be between {lo} and {hi}.")
    for c in CAT:
        df[c] = df[c].astype(str).str.strip()
        bad = sorted(set(df[c]) - set(CATEGORIES[c]))
        if bad:
            raise ValueError(f"{LABELS[c]} has unsupported value(s) {bad}. "
                             f"Allowed: {CATEGORIES[c]}")
    return df


def predict_frame(df: pd.DataFrame):
    X = PRE.transform(df)
    proba = MODEL.predict_proba(X)[:, 1]
    return (proba >= 0.5).astype(int), proba


IMPORTANCE = REPORT.get("feature_importance", {})
STD = {c: float(bundle["preprocessor"].named_transformers_["num"].scale_[i])
       for i, c in enumerate(NUM)}


def explain(row: pd.DataFrame, base_proba: float, label: str, top_n: int = 3):
    """Explain the prediction with the features that pushed it toward the
    predicted class.
    1) Occlusion: replace one feature at a time with its typical training value
       (median / most common) and measure the change in attack probability.
    2) If the model is so confident that no single change matters, fall back to
       feature importance x how far the value is from typical."""
    sign = 1 if label == "Attack" else -1          # direction we explain
    scored = []
    for f in FEATURES:
        alt = row.copy()
        alt[f] = BASELINES[f]
        p_alt = MODEL.predict_proba(PRE.transform(alt))[:, 1][0]
        scored.append((f, sign * (base_proba - p_alt)))
    scored = [(f, e) for f, e in scored if e > 0.005]
    if not scored:                                  # fallback (saturated model)
        for f in FEATURES:
            if f in NUM:
                dev = abs(float(row[f].iloc[0]) - BASELINES[f]) / (STD[f] or 1.0)
            else:
                dev = 0.0 if row[f].iloc[0] == BASELINES[f] else 1.0
            scored.append((f, IMPORTANCE.get(f, 0.0) * dev))
        scored = [(f, e) for f, e in scored if e > 0]
    scored.sort(key=lambda t: t[1], reverse=True)
    top = scored[:top_n]
    max_e = max((e for _, e in top), default=1.0) or 1.0
    return [{"feature": LABELS[f], "value": str(row[f].iloc[0]),
             "weight": max(8, round(e / max_e * 100))} for f, e in top]


def explanation_text(label: str, factors: list) -> str:
    if not factors:
        return "No single feature stood out for this session."
    items = ", ".join(f"{f['feature']} ({f['value']})" for f in factors)
    if label == "Attack":
        return f"Flagged as an attack mainly because of: {items}."
    return f"Classified as normal. Features that most supported this: {items}."


# ------------------------------------------------------------------- pages
@app.route("/")
def home():
    return render_template("home.html", active="home")


@app.route("/predict")
def predict_page():
    return render_template("predict.html", active="predict",
                           categories=CATEGORIES)


@app.route("/about")
def about():
    return render_template("about.html", active="about", report=REPORT)


@app.route("/relevance")
def relevance():
    return render_template("relevance.html", active="relevance")


# --------------------------------------------------------------------- API
@app.post("/api/predict")
def api_predict():
    """Single-session prediction from the manual form (JSON)."""
    data = request.get_json(silent=True) or {}
    try:
        df = validate_frame(pd.DataFrame([data]))
        pred, proba = predict_frame(df)
    except ValueError as e:
        return jsonify(error=str(e)), 400
    label = "Attack" if pred[0] == 1 else "Normal"
    factors = explain(df, float(proba[0]), label)
    return jsonify(label=label, probability=round(float(proba[0]), 4),
                   factors=factors, explanation=explanation_text(label, factors),
                   model=bundle["model_name"])


@app.post("/api/predict_csv")
def api_predict_csv():
    """Batch prediction from an uploaded CSV file."""
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".csv"):
        return jsonify(error="Please upload a .csv file."), 400
    try:
        # keep_default_na=False so the encryption value "None" stays a category
        raw = pd.read_csv(io.BytesIO(f.read()), keep_default_na=False, na_values=[""])
        if raw.empty:
            raise ValueError("The CSV file has no rows.")
        ids = raw["session_id"].astype(str) if "session_id" in raw else \
            pd.Series(range(1, len(raw) + 1)).astype(str)
        df = validate_frame(raw)
        pred, proba = predict_frame(df)
    except ValueError as e:
        return jsonify(error=str(e)), 400
    except Exception:
        return jsonify(error="Could not read the CSV file."), 400
    rows = [{"row": i + 1, "session": ids.iloc[i],
             "label": "Attack" if p == 1 else "Normal",
             "probability": round(float(pr), 4)}
            for i, (p, pr) in enumerate(zip(pred, proba))]
    return jsonify(rows=rows, total=len(rows),
                   attacks=int(pred.sum()), normal=int(len(pred) - pred.sum()))


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="File too large (max 5 MB)."), 413


if __name__ == "__main__":
    app.run(debug=True)
