"""
SAFE Flow: Stratified Analysis for Network Flow
Machine-learning pipeline (paper sections II.B - II.E)

Steps
  1. Collect and document the Cybersecurity Intrusion Detection Dataset
  2. Preprocess (drop session_id, check missing/duplicates, one-hot, standardize)
  3. 80:20 stratified split (scaler/encoder fitted on the training set only)
  4. Train Random Forest, Logistic Regression, Decision Tree, SVM
  5. Evaluate (accuracy, precision, recall, F1, confusion matrix; attack recall first)
  6. Save best model + preprocessing objects + report with joblib

Run:  python train_model.py
"""
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

RANDOM_STATE = 42
BASE = Path(__file__).parent
DATA_PATH = BASE / "data" / "cybersecurity_intrusion_data.csv"
MODEL_PATH = BASE / "models" / "safe_flow_model.joblib"
REPORT_PATH = BASE / "models" / "report.json"

TARGET = "attack_detected"
ID_COL = "session_id"
CATEGORICAL = ["protocol_type", "encryption_used", "browser_type"]
NUMERICAL = ["network_packet_size", "login_attempts", "session_duration",
             "ip_reputation_score", "failed_logins", "unusual_time_access"]
FEATURES = NUMERICAL + CATEGORICAL


# ----------------------------------------------------------------- 1. COLLECTION
def load_and_document(path: Path) -> pd.DataFrame:
    # keep_default_na=False: the value "None" in encryption_used means NO
    # encryption, it is a real category and must not be read as missing (NaN).
    df = pd.read_csv(path, keep_default_na=False, na_values=[""])
    print("=" * 60)
    print("DATASET DOCUMENTATION")
    print("=" * 60)
    print(f"Records   : {len(df):,}")
    print(f"Attributes: {df.shape[1]}")
    print("\nData types:")
    print(df.dtypes.to_string())
    counts = df[TARGET].value_counts().sort_index()
    print("\nClass distribution (0 = normal, 1 = attack):")
    for k, v in counts.items():
        print(f"  {k}: {v:,} ({v / len(df):.1%})")
    return df


# ----------------------------------------------------------- 2. PREPROCESSING
def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop(columns=[ID_COL])  # identifier, no predictive value
    print("\nMissing values per column:")
    print(df.isna().sum().to_string())
    n_dup = int(df.duplicated().sum())
    print(f"Duplicate records: {n_dup}")
    before = len(df)
    df = df.drop_duplicates().dropna().reset_index(drop=True)
    print(f"Rows removed during cleaning: {before - len(df)}")
    return df


def build_preprocessor() -> ColumnTransformer:
    return ColumnTransformer([
        ("num", StandardScaler(), NUMERICAL),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
    ])


# ------------------------------------------------------------------ 3-5. MODELS
def get_models(class_weight):
    return {
        "Random Forest": RandomForestClassifier(
            n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1,
            class_weight=class_weight),
        "Logistic Regression": LogisticRegression(
            max_iter=1000, random_state=RANDOM_STATE, class_weight=class_weight),
        "Decision Tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE, class_weight=class_weight),
        "SVM": SVC(kernel="rbf", probability=True, random_state=RANDOM_STATE,
                   class_weight=class_weight),
    }


def evaluate(y_true, y_pred) -> dict:
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def select_best(results: dict) -> str:
    """Best overall performance with priority on attack-class recall.
    Only models whose F1 is within 0.02 of the top F1 compete, then the one
    with the highest attack recall wins (this blocks a model that simply
    labels everything as 'attack' from winning on recall alone)."""
    top_f1 = max(r["f1"] for r in results.values())
    pool = {k: v for k, v in results.items() if v["f1"] >= top_f1 - 0.02}
    return max(pool, key=lambda k: (pool[k]["recall"], pool[k]["f1"]))


def main():
    if not DATA_PATH.exists():
        sys.exit(f"Dataset not found at {DATA_PATH}. Download it from Kaggle and place it there.")

    df = clean(load_and_document(DATA_PATH))
    X, y = df[FEATURES], df[TARGET]

    # 80:20 stratified split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=RANDOM_STATE)
    print(f"\nTrain: {len(X_train):,}  Test: {len(X_test):,}")

    # Fit scaler/encoder on TRAIN only -> no data leakage
    pre = build_preprocessor()
    Xtr = pre.fit_transform(X_train)
    Xte = pre.transform(X_test)

    # Class weighting only if classes are imbalanced
    minority_share = y.value_counts(normalize=True).min()
    imbalanced = minority_share < 0.40
    class_weight = "balanced" if imbalanced else None
    print(f"Minority class share: {minority_share:.1%} -> "
          f"class weighting {'ON' if imbalanced else 'OFF'}")

    results, fitted = {}, {}
    print("\nMODEL EVALUATION (attack class = 1)")
    print("-" * 60)
    for name, model in get_models(class_weight).items():
        model.fit(Xtr, y_train)
        res = evaluate(y_test, model.predict(Xte))
        results[name], fitted[name] = res, model
        cm = res["confusion_matrix"]
        print(f"{name:<20} acc={res['accuracy']:.4f} prec={res['precision']:.4f} "
              f"recall={res['recall']:.4f} f1={res['f1']:.4f}  "
              f"[TN={cm['tn']} FP={cm['fp']} FN={cm['fn']} TP={cm['tp']}]")

    best = select_best(results)
    print(f"\nBest model (priority: attack-class recall): {best}")

    # Baselines used for the per-session explanation in the web app
    baselines = {c: float(X_train[c].median()) for c in NUMERICAL}
    baselines.update({c: X_train[c].mode().iloc[0] for c in CATEGORICAL})

    # Feature importance (Random Forest, aggregated back to original columns)
    rf = fitted["Random Forest"]
    names = pre.get_feature_names_out()
    imp = {}
    for n, v in zip(names, rf.feature_importances_):
        orig = n.split("__", 1)[1]
        key = next((c for c in CATEGORICAL if orig.startswith(c + "_")), orig)
        imp[key] = imp.get(key, 0.0) + float(v)

    bundle = {
        "preprocessor": pre,                 # fitted scaler + encoder
        "model": fitted[best],
        "model_name": best,
        "features": FEATURES,
        "numerical": NUMERICAL,
        "categorical": CATEGORICAL,
        "categories": {c: sorted(X[c].unique().tolist()) for c in CATEGORICAL},
        "baselines": baselines,
    }
    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(bundle, MODEL_PATH)

    report = {
        "dataset": {
            "records": int(len(df)), "attributes": int(df.shape[1] + 1),
            "normal": int((y == 0).sum()), "attack": int((y == 1).sum()),
            "source": "Cybersecurity Intrusion Detection Dataset (Samudrala), Kaggle",
        },
        "split": {"train": int(len(X_train)), "test": int(len(X_test))},
        "class_weighting": bool(imbalanced),
        "best_model": best,
        "models": results,
        "feature_importance": dict(sorted(imp.items(), key=lambda kv: -kv[1])),
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2))
    print(f"\nSaved model  -> {MODEL_PATH}")
    print(f"Saved report -> {REPORT_PATH}")


if __name__ == "__main__":
    main()
