# SAFE Flow: Stratified Analysis for Network Flow

Web-based network intrusion detection (Flask + scikit-learn) following the group paper and proposal.

## Setup
```bash
pip install -r requirements.txt
```
Dataset: `data/cybersecurity_intrusion_data.csv`
(Kaggle: dnkumars/cybersecurity-intrusion-detection-dataset)

## Run
```bash
python train_model.py   # documents data, trains 4 models, saves models/safe_flow_model.joblib
python app.py           # open http://127.0.0.1:5000
```

## Files
- `train_model.py` - pipeline (collection, preprocessing, 80:20 stratified split, 4 classifiers, evaluation, joblib save)
- `app.py` - Flask app (Home, Predict, About, Relevance + JSON/CSV prediction endpoints)
- `templates/`, `static/` - HTML, CSS, JavaScript front end
- `sample_sessions.csv` - small CSV for testing the upload feature

Note: the dataset's encryption value "None" means no encryption. The code reads it as its own
category (`keep_default_na=False`), not as a missing value.
