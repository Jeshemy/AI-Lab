// SAFE Flow - Predict page logic: input checks, calls to Flask, rendering results.
const $ = (s) => document.querySelector(s);
const manualForm = $("#manual-form"), csvForm = $("#csv-form"), errBox = $("#error");

const showError = (m) => { errBox.textContent = m; errBox.hidden = !m; };
const esc = (t) => String(t).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

// Tabs
document.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t === tab));
  const manual = tab.dataset.tab === "manual";
  manualForm.hidden = !manual; csvForm.hidden = manual; showError("");
}));

// Manual prediction
manualForm.addEventListener("submit", async (e) => {
  e.preventDefault(); showError("");
  const data = Object.fromEntries(new FormData(manualForm).entries());
  for (const el of manualForm.querySelectorAll("input")) {
    if (el.value.trim() === "") return showError(`Please fill in: ${el.closest("label").childNodes[0].textContent.trim()}.`);
    const v = Number(el.value), min = el.min !== "" ? Number(el.min) : -Infinity, max = el.max !== "" ? Number(el.max) : Infinity;
    if (Number.isNaN(v) || v < min || v > max) return showError(`${el.closest("label").childNodes[0].textContent.trim()} is out of range.`);
  }
  try {
    const res = await fetch("/api/predict", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(data)});
    const out = await res.json();
    if (!res.ok) return showError(out.error || "Prediction failed.");
    renderSingle(out);
  } catch { showError("Could not reach the server."); }
});

function renderSingle(o) {
  const atk = o.label === "Attack", pct = Math.round(o.probability * 100);
  $("#result").className = "result";
  $("#result").innerHTML = `<div class="label ${atk ? "attack" : "normal"}">${atk ? "Attack detected" : "Normal session"}</div>
    <div>Probability of attack: <b>${o.probability.toFixed(2)}</b> <span class="hint">(model: ${esc(o.model)})</span></div>
    <div class="meter ${atk ? "" : "ok"}"><div style="width:${pct}%"></div></div>`;
  $("#explain").className = "";
  $("#explain").innerHTML = `<p>${esc(o.explanation)}</p>` + o.factors.map((f) =>
    `<div class="factor"><span>${esc(f.feature)}</span><div class="meter"><div style="width:${f.weight}%"></div></div></div>`).join("");
  $("#csv-results").hidden = true;
}

// CSV prediction
csvForm.addEventListener("submit", async (e) => {
  e.preventDefault(); showError("");
  const file = $("#csv-file").files[0];
  if (!file) return showError("Choose a CSV file first.");
  const fd = new FormData(); fd.append("file", file);
  try {
    const res = await fetch("/api/predict_csv", {method: "POST", body: fd});
    const out = await res.json();
    if (!res.ok) return showError(out.error || "Upload failed.");
    $("#csv-summary").textContent = `${out.total} sessions analyzed: ${out.attacks} attack, ${out.normal} normal.`;
    $("#csv-body").innerHTML = out.rows.map((r) =>
      `<tr><td>${r.row}</td><td>${esc(r.session)}</td><td class="${r.label.toLowerCase()}">${r.label}</td><td>${r.probability.toFixed(2)}</td></tr>`).join("");
    $("#csv-results").hidden = false;
  } catch { showError("Could not reach the server."); }
});
